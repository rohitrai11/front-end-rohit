package com.dss;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Complaint extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		//General Setting
		response.setContentType("text/html");
		        Connection con=null;
		        PrintWriter out=response.getWriter();
		        //HttpSession session=request.getSession(false);
		        int p=0,q=0,f=0;
		try{   
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			con=DriverManager.getConnection("jdbc:oracle:thin:@Localhost:1521:xe","system","oracle");}catch(ClassNotFoundException e){out.println(e);} catch (SQLException e) { 
		out.println(e);
		} 
		String status="pending";
		Cookie c[]=request.getCookies();
		//Request Gathering Logic
		String vnum=request.getParameter("vnum");
		//String s=vnum.substring(0, 4);
		//out.println(s);
		try
		{
		PreparedStatement st,st1;
		//st = con.prepareStatement("create table ? (Vno varchar2(30),Username varchar2(30),Status varchar2(20))");
		//st.setString(1, s);
		//p=st.executeUpdate();
		st1 = con.prepareStatement("insert into Complaint values(?,?,?)");
		//out.println("Hello");
		//st1.setString(1, s);
		//out.println("Hello2");
		st1.setString(1, vnum);
		//out.println("Hello3");
		//out.println(c[0].getValue());
		st1.setString(2, c[1].getValue());
		st1.setString(3, status);
		//out.println("Hello4");
		q=st1.executeUpdate();
		//out.println("Hello5");
		}
		catch(Exception e)
		{
			out.println(e);
		}
		response.sendRedirect("loginsuccess.jsp");
}
}