package com.dss;

import java.io.IOException;
import java.security.*;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.security.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import oracle.net.ns.SessionAtts;

import javax.servlet.http.Cookie;
import java.math.*;

public class LoginServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
        HttpSession session=request.getSession(false);
        String name=request.getParameter("uname");  
        String pwd=request.getParameter("psw");
        String regno=request.getParameter("regno");
       String cap=request.getParameter("captcha");
       String capget=session.getAttribute("logincaptcha").toString();
        String realpassword=null;
        String logintype=null;
        String reg=null;
        MessageDigest m = null;
		try {
			m = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        m.update(pwd.getBytes(),0,pwd.length());
        pwd=new BigInteger(1,m.digest()).toString(16);
       Cookie c1=new Cookie("name",name);
       response.addCookie(c1);
          Connection con=null;  
        try{  
        	Class.forName("oracle.jdbc.driver.OracleDriver");
        	con=DriverManager.getConnection("jdbc:oracle:thin:@Localhost:1521:xe","system","oracle");
        }catch(Exception e){out.println(e);} 
        try{  
            
            PreparedStatement ps=con.prepareStatement("select * from logintable where Username=?");  
            ps.setString(1,name);  
            ResultSet rs=ps.executeQuery();  
            if(rs.next()){  
                 
               realpassword=rs.getString(2);  
                logintype=rs.getString(3); 
                reg=rs.getString(4);
                
                  
            }  
            
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
       if(pwd.equals(realpassword) && reg.equals(regno) && cap.equals(capget))
       {
    	   //response.sendRedirect("loginsuccess.jsp");
    	   //response.sendRedirect("Demo.jsp");
    	   //out.println(pwd);
           //out.println("welcome : "+name);
    	   /*HttpSession session=request.getSession();
            session=request.getSession();  
             session.setAttribute("name",name);
             session.setAttribute("logintype",logintype);*/
           if(logintype.equals("Citizen")){
               response.sendRedirect("loginsuccess.jsp");
           }
           else if(logintype.equals("RTO Officer"))
           {
               response.sendRedirect("RTO_Officer.jsp");
           }  
       }
       else{
           response.sendRedirect("loginerr.html");
    	   //request.getRequestDispatcher("loginerr.html").include(request, response);
       }
       
       out.close();
	}

}
