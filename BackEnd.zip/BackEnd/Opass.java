package com.dss;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Opass extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
            
        String pwd=request.getParameter("Opass"); 
        String realpassword;
        MessageDigest m;
		try 
		{
			m = MessageDigest.getInstance("MD5");
            m.update(pwd.getBytes(),0,pwd.length());
                   pwd=new BigInteger(1,m.digest()).toString(16);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			out.println(e);
		}

 
          Connection con=null;
          //HttpSession session=request.getSession(false);
          Cookie []c=request.getCookies();
          //out.println("Username: "+c[0].getValue());

        try{  
        	Class.forName("oracle.jdbc.driver.OracleDriver");
        	con=DriverManager.getConnection("jdbc:oracle:thin:@Localhost:1521:xe","system","oracle"); 
        }catch(ClassNotFoundException e){out.println(e);} catch (SQLException e) { 
            out.println(e);
        } 
        try{  
            //out.println("Hello1");
            PreparedStatement ps=con.prepareStatement("select Password from logintable where Username =?");  
            //out.println("Hello2");
            ps.setString(1,c[1].getValue());
            //out.println("Hello3");
            ResultSet rs=ps.executeQuery();
            //out.println("Hello4");
            if(rs.next())
            {     
               realpassword=rs.getString(1);
               if(realpassword.equals(pwd))
               {
                   response.sendRedirect("cpass1.jsp");
               }
            else
               {
            	out.println("<html>");
            	out.println("<body>");
            	out.println("<script>");
            	out.println("confirm('Password does not exist')");
            	out.println("</script>");
            	out.println("</body>");
            	out.println("</html>");
            	response.sendRedirect("cpass.jsp");
               }
                  
            }  
            con.close();  
        }catch(SQLException e){out.println(e);} catch (IOException e) {
            out.println(e);
        }

	}

}
