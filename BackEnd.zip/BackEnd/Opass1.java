package com.dss;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Opass1 extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
          
        String newpwd=request.getParameter("Password");
        String repwd=request.getParameter("Re_password");
        MessageDigest m = null;
		try {
			m = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        m.update(newpwd.getBytes(),0,newpwd.length());
        newpwd=new BigInteger(1,m.digest()).toString(16);
        m.update(repwd.getBytes(),0,repwd.length());
        repwd=new BigInteger(1,m.digest()).toString(16);
        Connection con=null;
        //HttpSession session=request.getSession(false);
         Cookie []c=request.getCookies();
        try{  
        	Class.forName("oracle.jdbc.driver.OracleDriver");
        	con=DriverManager.getConnection("jdbc:oracle:thin:@Localhost:1521:xe","system","oracle");   
        }catch(ClassNotFoundException e){out.println(e);} catch (SQLException e) { 
            out.println(e);
        }
        try{  
               if(newpwd.equals(repwd))
               {
                   PreparedStatement ps=con.prepareStatement("update logintable set Password=? where Username=?");
                   out.println("Hello1");
            //ps.setString(1,session.getAttribute("Username").toString());
            ps.setString(1,newpwd);
            ps.setString(2,c[1].getValue());
            out.println(c[1].getValue());
            int p=ps.executeUpdate();
            out.println("Hello3");
            if(p!=0)
            {
            	out.println("<html>");
            	out.println("<body>");
            	out.println("<script>");
            	out.println("alert('Password changed successfully')");
            	out.println("</script>");
            	out.println("</body>");
            	out.println("</html>");
            	response.sendRedirect("loginsuccess.jsp");
            }
            else
            {
             	out.println("<html>");
            	out.println("<body>");
            	out.println("<script>");
            	out.println("alert('Password did not change')");
            	out.println("</script>");
            	out.println("</body>");
            	out.println("</html>");
            }
        }
        }catch(Exception e){
            out.println(e);}
               
       
	}

}
