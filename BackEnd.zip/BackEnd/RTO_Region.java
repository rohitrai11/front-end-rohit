package com.dss;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class RTO_Region extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//General Setting
		response.setContentType("text/html");
		        Connection con=null;
		        PrintWriter out=response.getWriter();
		try{  
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@Localhost:1521:xe","system","oracle");}
		catch(ClassNotFoundException e){out.println(e);} catch (SQLException e) { 
		out.println(e);
		} 
		String Rcode=request.getParameter("Rcode");
		//out.println(Rcode);
		Cookie c2=new Cookie("Rcode",Rcode);
	       response.addCookie(c2);
	       Cookie []c=request.getCookies();
	       //out.print(c[0].getValue()+"   "+c[2].getValue());
	       response.sendRedirect("Officer_Show.jsp");
		/*try
		{
		PreparedStatement st;
		            st = con.prepareStatement("select * from Complaint");
		            ResultSet rs=st.executeQuery();
		            while(rs.next())
		            {
		            	if(rs.getString(1).substring(0, 4).equals(r))
		            	{
		            		out.println(rs.getString(1)+"<br/>");
			            	out.println(rs.getString(2)+"<br/>");
			            	out.println(rs.getString(3)+"<br/>");
		            	}
		            }
		}catch(Exception e)
		{
			out.println(e);
		}*/

	}
}