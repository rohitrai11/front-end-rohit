package com.dss;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Register1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//Request Gathering Logic
        String User_type=request.getParameter("User_type");
String Fname=request.getParameter("Fname");
String Lname=request.getParameter("Lname");
        String Gender=request.getParameter("Gender");
        String Email=request.getParameter("Email");
//creating Http session object
HttpSession session=request.getSession();
//Adding values to Http Session
        session.setAttribute("User_type",User_type);
session.setAttribute("Fname",Fname);
        session.setAttribute("Lname",Lname);
        session.setAttribute("Gender",Gender);
        session.setAttribute("Email",Email);
//forwarding request to next form
RequestDispatcher rd=request.getRequestDispatcher("signup2.jsp");
rd.forward(request, response);
}

	}
