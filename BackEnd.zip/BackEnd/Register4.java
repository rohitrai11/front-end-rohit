package com.dss;
import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.security.*;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.math.*;
import java.sql.SQLException;
public class Register4 extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
        //General Setting
response.setContentType("text/html");
        Connection con=null;
        PrintWriter out=response.getWriter();
        int p=0,q=0,f=0;
try{   
	Class.forName("oracle.jdbc.driver.OracleDriver");
	con=DriverManager.getConnection("jdbc:oracle:thin:@Localhost:1521:xe","system","oracle");}catch(ClassNotFoundException e){out.println(e);} catch (SQLException e) { 
out.println(e);
out.println("hello1");
} 
        
//Request Gathering Logic
String Username=request.getParameter("Username");
String Password=request.getParameter("Password");
String Re_password=request.getParameter("Re_password");


	int i,index;
	String str="0123456789";
	String capcha="";
	char c;




		for(i=0;i<10;i++)
		{   
			index=(int) (Math.random() * 10); 
			c=str.charAt(index);
			capcha+=c;
		}
		

if(Password.equals(Re_password))
{
    MessageDigest m = null;
try {
m = MessageDigest.getInstance("MD5");
} catch (NoSuchAlgorithmException e1) {
//TODO Auto-generated catch block
e1.printStackTrace();
out.println("hello2");
}
m.update(Password.getBytes(),0,Password.length());
Password=new BigInteger(1,m.digest()).toString(16);
//creating Http session object
HttpSession session=request.getSession(false);
session.setAttribute("Username", Username);
session.setAttribute("capcha", capcha);
capcha="";
//inserting values into registertable
/*out.println(session.getAttribute("Fname").toString());
out.println(session.getAttribute("Lname").toString());
out.println(session.getAttribute("Gender").toString());
out.println(session.getAttribute("Email").toString());
out.println(session.getAttribute("Mobno").toString());
out.println(session.getAttribute("Adharno").toString());
out.println(session.getAttribute("City").toString());
out.println(session.getAttribute("State").toString());
out.println(session.getAttribute("Pincode").toString());
out.println(Username);
out.println(Password);*/
try
{
PreparedStatement st;
     st = con.prepareStatement("insert into registertable values(?,?,?,?,?,?,?,?,?,?,?)");
st.setString(1, session.getAttribute("Fname").toString());
st.setString(2, session.getAttribute("Lname").toString());
st.setString(3, session.getAttribute("Gender").toString());
st.setString(4, session.getAttribute("Email").toString());
     st.setString(5, session.getAttribute("Mobno").toString());
     st.setString(6, session.getAttribute("Adharno").toString());
     st.setString(7, session.getAttribute("City").toString());
     st.setString(8, session.getAttribute("State").toString());
     st.setString(9, session.getAttribute("Pincode").toString());
     st.setString(10, Username);
     st.setString(11, session.getAttribute("User_type").toString());
     p=st.executeUpdate();
}
catch(Exception e)
{
	response.sendRedirect("registerfail.html");
	out.println("hello1");
}
try
{
  PreparedStatement st1;
  st1 = con.prepareStatement("insert into logintable values(?,?,?,?)");
     st1.setString(1, Username);
st1.setString(2, Password);
st1.setString(3, session.getAttribute("User_type").toString());
st1.setString(4, session.getAttribute("capcha").toString());
     q=st1.executeUpdate();
     if(p!=0&&q!=0) 
{
//out.println("Registration success");
             response.sendRedirect("Registersuccess.jsp");
}
else
{
out.println("Registration failed");
}
}
catch(SQLException e)
{
out.println(e);
out.println("hello10");
} catch (IOException e) {
 out.println(e);
 out.println("hello11");
}
}
else{
	response.sendRedirect("signup4.html");
}
 }

}
