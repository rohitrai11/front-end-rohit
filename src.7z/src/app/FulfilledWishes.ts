export class FulfilledWishes{
    fulfilledId: number;
    wishId: number;
    wishes: String;
    empId:number;
}