import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HttpModule } from '@angular/http';
import { RegisterComponent } from './register/register.component';
import {RegisterService} from './register/register.service';
import { LoginComponent } from './login/login.component'
import { LoginService } from './login/login.service';
import { MainpageComponent } from './mainpage/mainpage.component';
import { MainpageService } from './mainpage/mainpage.service';
import { RouterModule } from '@angular/router';
import { ProfileAdminComponent } from './profile-admin/profile-admin.component';
import { ProfileAdminService } from './profile-admin/profile-admin.service';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    MainpageComponent,
    ProfileAdminComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule
  ],
  providers: [RegisterService,LoginService,MainpageService,ProfileAdminService],
  bootstrap: [AppComponent]
})
export class AppModule { }
