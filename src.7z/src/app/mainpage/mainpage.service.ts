import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import {Headers} from '@angular/http';
import {User} from '../User';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class MainpageService {
  private headers = new Headers({'Content-Type': 'application/json'} );
  constructor(private http:Http) { }

  mainpage(data):Promise<User> {
    return this.http.post('http://localhost:3333/WishLab_BackEnd/wishesAPI/mainpage', JSON.stringify(data.value), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
  }

  handleError(error){
    return Promise.reject(error.json() || error);
  }

}   