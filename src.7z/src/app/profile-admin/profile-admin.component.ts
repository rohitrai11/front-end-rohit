import { Component, OnInit, Input } from '@angular/core';
import {User} from '../User';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import {ProfileAdminService} from './profile-admin.service';
import {FulfilledWishes} from '../FulfilledWishes';
import { WishList } from '../WishList';
import {LoginComponent} from '../login/login.component';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'profile-admin',
  templateUrl: './profile-admin.component.html',
  styleUrls: ['./profile-admin.component.css']
})
export class ProfileAdminComponent implements OnInit {
  public fw: FulfilledWishes[] = [];
  public wl: WishList[]=[];
  private sub:any;
  admin:User;
  successMessage:string;
  errorMessage:string;
  addWishForm: FormGroup;

  constructor(private route: ActivatedRoute,private profSer:ProfileAdminService, private formBuilder:FormBuilder) { }
  getWishList(){
    this.profSer.getWishList().then(response=>{
      for(let i of response)
      {
        this.wl.push(i);
      
      }
      alert("Hello "+response[0].wishes)}).catch(response=>{alert("Hii "+response)}
      );
  }
  
  getFulfilled(){
    this.profSer.getFulfilled().then(response=>{
      for(let i of response)
      {
        this.fw.push(i);
      
      }
      alert("Hello "+response[0].wishes)}).catch(response=>{alert("Hii "+response)});  
  }

addWish(){
  alert(JSON.stringify(this.addWishForm.value))
  this.profSer.addWish(this.addWishForm).then(response=>{this.successMessage=response.message;
  alert("Hello "+this.successMessage);
}).catch(response=>{this.errorMessage=response.message;alert("Hionohnjo "+this.errorMessage);});

}


  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      // (+) converts string 'id' to a number
      alert( params['response']);
      // In a real app: dispatch action to load the details here.
   });
    
    this.addWishForm=this.formBuilder.group(
      {
        wishes:["",[Validators.required]],
        quantity:["",[Validators.required]],
        priority:["",[Validators.required]],
        reward:["",[Validators.required]],
        status:["Required"],
        message:[""],
        adminId:[this.admin.registerId]

       }
    );
  }

}
