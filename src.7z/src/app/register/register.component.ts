import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import {RegisterService} from './register.service'

@Component({
  selector: 'register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
    
    successMessage:string;
    errorMessage:string;
    registerId:any;
    registerForm:FormGroup;
    
    constructor(private formBuilder:FormBuilder,private registerService:RegisterService) { }
  
    ngOnInit() {

     this.registerForm=this.formBuilder.group(
       { 
          registerAs:["",[Validators.required]],
          name:["",[Validators.required]],
          dept:["",[Validators.required]],
          address:["",[Validators.required]],
          contactNo:["",[Validators.required]],
          email:["",[Validators.required]],
          password:["",[Validators.required]]
        }
     );
    }


    register() {
      alert(JSON.stringify(this.registerForm.value))
      if(this.registerForm.value.registerAs=="ADMIN")
      {
        this.registerService.registerAdmin(this.registerForm).then(response=>{this.registerId=response.registerId;this.successMessage=response.message
alert("Hello "+this.successMessage)}).catch(response=>this.errorMessage=response.message);
    }
    else if(this.registerForm.value.registerAs=="EMPLOYEE")
    {
      this.registerService.registerEmployee(this.registerForm).then(response=>{this.registerId=response.registerId;this.successMessage=response.message
        alert("Hello "+this.successMessage)}).catch(response=>this.errorMessage=response.message);
    }
    else if(this.registerForm.value.registerAs=="VOLUNTEER")
    {
      this.registerService.registerVolunteer(this.registerForm).then(response=>{this.registerId=response.registerId;this.successMessage=response.message
        alert("Hello "+this.successMessage)}).catch(response=>this.errorMessage=response.message);
    }
    
    }
      
  

}
