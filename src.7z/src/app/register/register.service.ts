import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import {Headers} from '@angular/http';
import {User} from '../User';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class RegisterService {
  private headers = new Headers({'Content-Type': 'application/json'} );
  constructor(private http:Http) { }

  registerAdmin(data):Promise<User> {
    alert(data.value.registerAs)
    return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/registerAdmin', JSON.stringify(data.value), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
  }
  registerEmployee(data):Promise<User> {
    alert(data.value.registerAs)
    return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/registerEmployee', JSON.stringify(data.value), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
  }
  registerVolunteer(data):Promise<User> {
    alert(data.value.registerAs)
    return this.http.post('http://localhost:3333/Wishlab_BackEnd/wishesAPI/registerVolunteer', JSON.stringify(data.value), {headers: this.headers})    
  .toPromise()
  .then(response=>response.json())    
  .catch(this.handleError);
  }

  handleError(error){
    return Promise.reject(error.json() || error);
  }

}   