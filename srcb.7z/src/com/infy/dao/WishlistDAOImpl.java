package com.infy.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.management.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.AdminEntity;
import com.infy.entity.EmployeeEntity;
import com.infy.entity.FullfilledEntity;
import com.infy.entity.PickedEntity;
import com.infy.entity.VolunteerEntity;
import com.infy.entity.WishesEntity;
import com.infy.model.Admin;
import com.infy.model.Employee;
import com.infy.model.Volunteer;
import com.infy.model.Wishlist;



@Repository(value="dao")
public class WishlistDAOImpl implements WishlistDAO {

	@Autowired
	SessionFactory sessionFactory;
	
	public PickedEntity pickWishes(Wishlist wishes) throws Exception {
		
		Session session = sessionFactory.getCurrentSession();
		
		PickedEntity picked = null;
		//System.out.println(wishes.getWishes());
		WishesEntity wish = (WishesEntity) session.get(WishesEntity.class, wishes.getWishes());
		if(wish!=null && wish.getQuantity()>=wishes.getQuantity()){
			Integer s=wish.getQuantity()-wishes.getQuantity();
			wish.setQuantity(s);
			picked=new PickedEntity();
			picked.setDateOfSelection(LocalDate.now());
			
			picked.setQuantity(wishes.getQuantity());
			wishes.setStatus("Pending");
			picked.setStatus(wishes.getStatus());
			picked.setWishes(wishes.getWishes());
			session.persist(picked);
		}
		//System.out.println(picked);
		// persisting the flightsBookingEntity object
		return picked;
	}

	public String addWishes(Wishlist newWish) throws Exception{
		//System.out.println("dao");
		Session session = sessionFactory.getCurrentSession();
		
		//System.out.println(newWish.getWishes());
		WishesEntity wish=session.get(WishesEntity.class,newWish.getWishes());
		//System.out.println(wish);
		if(wish==null){
			wish=new WishesEntity();
		wish.setAdminId(newWish.getAdminId());
		wish.setPriority(newWish.getPriority());
		wish.setQuantity(newWish.getQuantity());
		wish.setReward(newWish.getReward());
		wish.setStatus("Required");
		wish.setWishes(newWish.getWishes());
		session.persist(wish);
		}
		else{
			wish.setQuantity(wish.getQuantity()+newWish.getQuantity());
		}
		return newWish.getWishes();
	}
	
	
	public void updateStatus(Integer wishId) throws Exception{
		//System.out.println(wishId);
		Session session = sessionFactory.getCurrentSession();
		PickedEntity pwish=session.get(PickedEntity.class,wishId);
		//System.out.println("pwish="+pwish);
		if(pwish!=null){
			pwish.setStatus("Completed");
				FullfilledEntity full=new FullfilledEntity();
				full.setWishes(pwish.getWishes());
				full.setEmpId(pwish.getEmpId());
				full.setWishId(wishId);
				session.persist(full);
				WishesEntity wish=session.get(WishesEntity.class,pwish.getWishes());
				if(wish!=null && wish.getQuantity()==0){
					session.delete(wish);
		}
	}
	}
		
	public Employee volunteerChoice(Employee emp)throws Exception{
		return null;
	}
	
	public boolean assignVolunteer(Integer vid)throws Exception{
		Session session = sessionFactory.getCurrentSession();
		VolunteerEntity volunteer=session.get(VolunteerEntity.class,vid);
		boolean r=false;
		if(volunteer!=null){
				r=true;
		}
		return r;
	}
	public boolean unpickWish(Integer wishId) throws Exception{
		Session session = sessionFactory.getCurrentSession();
		PickedEntity wish=session.get(PickedEntity.class,wishId);
		LocalDate select=wish.getDateOfSelection();
		LocalDate today=LocalDate.now();
		if(today.minusDays(5).isEqual(select) || today.minusDays(5).isBefore(select)){
			WishesEntity w=session.get(WishesEntity.class, wish.getWishes());
			if(w!=null){
				w.setQuantity(w.getQuantity()+wish.getQuantity());
			}
			
			return true;
		}
		return false;
	}
	public AdminEntity newAdmin(Admin admin) throws Exception{
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<AdminEntity> criteriaQuery = builder.createQuery(AdminEntity.class);
        Root<AdminEntity> root = criteriaQuery.from(AdminEntity.class);
        criteriaQuery.select(root);
        criteriaQuery.where(builder.equal(root.get("email"), admin.getEmail()));
       // System.out.println("HI");
        AdminEntity adm=session.createQuery(criteriaQuery).uniqueResult();
       // System.out.println(adm);
		if(adm==null){
			adm=new AdminEntity();
			//adm.setAdminId(admin.getAdminId());
			adm.setUsertype("Admin");
			adm.setAddress(admin.getAddress());
			adm.setContactNo(admin.getContactNo());
			adm.setDept(admin.getDept());
			adm.setEmail(admin.getEmail());
			adm.setName(admin.getName());
			adm.setPassword(admin.getPassword());
			session.persist(adm);
			return adm;
		}
		else
			return null;
	}
	public EmployeeEntity newEmployee(Employee employee) throws Exception{
		Session session = sessionFactory.getCurrentSession();
		EmployeeEntity adm=session.get(EmployeeEntity.class,employee.getEmpId());
		
		if(adm==null){
			adm=new EmployeeEntity();
			//adm.setAdminId(admin.getAdminId());
			adm.setUsertype("Employee");
			adm.setAddress(employee.getAddress());
			adm.setContactNo(employee.getContactNo());
			adm.setEmpDept(employee.getEmpDept());
			adm.setEmail(employee.getEmail());
			adm.setEmpName(employee.getEmpName());
			adm.setPassword(employee.getPassword());
			session.persist(adm);
			return adm;
		}
		else
			return null;
	}
	public VolunteerEntity newVolunteer(Volunteer volunteer) throws Exception{
		Session session = sessionFactory.getCurrentSession();
		VolunteerEntity adm=session.get(VolunteerEntity.class,volunteer.getvId());
		
		if(adm==null){
			adm=new VolunteerEntity();
			//adm.setAdminId(admin.getAdminId());
			adm.setUsertype("Volunteer");
			adm.setvAddress(volunteer.getvAddress());
			adm.setContactNo(volunteer.getContactNo());
			adm.setvDept(volunteer.getvDept());
			adm.setEmail(volunteer.getEmail());
			adm.setvName(volunteer.getvName());
			adm.setPassword(volunteer.getPassword());
			session.persist(adm);
			return adm;
		}
		else
			return null;
	}
	public AdminEntity adminLogin(String mail,String password){
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<AdminEntity> criteriaQuery = builder.createQuery(AdminEntity.class);
        Root<AdminEntity> root = criteriaQuery.from(AdminEntity.class);
        criteriaQuery.select(root);
        criteriaQuery.where(builder.equal(root.get("email"), mail));
        AdminEntity adm=session.createQuery(criteriaQuery).uniqueResult();

		if(adm!=null){
			if(adm.getPassword().equals(password))
				return adm;
			else
				return null;
		}
		return null;
	}
	public EmployeeEntity empLogin(String mail,String password){
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<EmployeeEntity> criteriaQuery = builder.createQuery(EmployeeEntity.class);
        Root<EmployeeEntity> root = criteriaQuery.from(EmployeeEntity.class);
        criteriaQuery.select(root);
        criteriaQuery.where(builder.equal(root.get("email"), mail));
        EmployeeEntity adm=session.createQuery(criteriaQuery).uniqueResult();
		if(adm!=null){
			if(adm.getPassword().equals(password))
				return adm;
			else
				return null;
		}
		return null;
	}
	public VolunteerEntity volLogin(String mail,String password){
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<VolunteerEntity> criteriaQuery = builder.createQuery(VolunteerEntity.class);
        Root<VolunteerEntity> root = criteriaQuery.from(VolunteerEntity.class);
        criteriaQuery.select(root);
        criteriaQuery.where(builder.equal(root.get("email"), mail));
        VolunteerEntity adm=session.createQuery(criteriaQuery).uniqueResult();
		if(adm!=null){
			if(adm.getPassword().equals(password))
				return adm;
			else
				return null;
		}
		return null;
	}
	public boolean changePassword(Admin admin){
		Session session = sessionFactory.getCurrentSession();
		//System.out.println(admin.getAdminId());
		AdminEntity adm=session.get(AdminEntity.class,admin.getAdminId());
		if(adm!=null){
			adm.setPassword(admin.getPassword());
			return true;}
		else
			return false;
	}
	public boolean empPassword(Employee employee){
		Session session = sessionFactory.getCurrentSession();
		//System.out.println(admin.getAdminId());
		EmployeeEntity adm=session.get(EmployeeEntity.class,employee.getEmpId());
		if(adm!=null){
			adm.setPassword(employee.getPassword());
			return true;}
		else
			return false;
	}
	public boolean volPassword(Volunteer volunteer){
		Session session = sessionFactory.getCurrentSession();
		//System.out.println(admin.getAdminId());
		VolunteerEntity adm=session.get(VolunteerEntity.class,volunteer.getvId());
		if(adm!=null){
			adm.setPassword(volunteer.getPassword());
			return true;}
		else
			return false;
	}
//	public List<AdminEntity> getAdminDetails(){
//		Session session = sessionFactory.getCurrentSession();
//		List<AdminEntity> admin=new ArrayList<AdminEntity>();
//		CriteriaBuilder builder = session.getCriteriaBuilder();
//        CriteriaQuery<AdminEntity> criteriaQuery = builder.createQuery(AdminEntity.class);
//        Root<AdminEntity> root = criteriaQuery.from(AdminEntity.class);
//        criteriaQuery.select(root);
//        List<AdminEntity> list=session.createQuery(criteriaQuery).list();
//        for(AdminEntity adm:list){
//        	admin.add(adm);
//	}
//        return admin;
//	}
//	public List<EmployeeEntity> getEmpDetails(){
//		Session session = sessionFactory.getCurrentSession();
//		List<EmployeeEntity> admin=new ArrayList<EmployeeEntity>();
//		CriteriaBuilder builder = session.getCriteriaBuilder();
//        CriteriaQuery<EmployeeEntity> criteriaQuery = builder.createQuery(EmployeeEntity.class);
//        Root<EmployeeEntity> root = criteriaQuery.from(EmployeeEntity.class);
//        criteriaQuery.select(root);
//        List<EmployeeEntity> list=session.createQuery(criteriaQuery).list();
//        for(EmployeeEntity adm:list){
//        	admin.add(adm);
//	}
//        return admin;
//	}
//	public List<VolunteerEntity> getVolDetails(){
//		Session session = sessionFactory.getCurrentSession();
//		List<VolunteerEntity> admin=new ArrayList<VolunteerEntity>();
//		CriteriaBuilder builder = session.getCriteriaBuilder();
//        CriteriaQuery<VolunteerEntity> criteriaQuery = builder.createQuery(VolunteerEntity.class);
//        Root<VolunteerEntity> root = criteriaQuery.from(VolunteerEntity.class);
//        criteriaQuery.select(root);
//        List<VolunteerEntity> list=session.createQuery(criteriaQuery).list();
//        for(VolunteerEntity adm:list){
//        	admin.add(adm);
//	}
//        return admin;
//	}
	
	public List<WishesEntity> getWishlist(){
		Session session = sessionFactory.getCurrentSession();
		//List<WishesEntity> admin=new ArrayList<WishesEntity>();
		CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<WishesEntity> criteriaQuery = builder.createQuery(WishesEntity.class);
        Root<WishesEntity> root=criteriaQuery.from(WishesEntity.class);
        criteriaQuery.select(root);

        List<WishesEntity> list=session.createQuery(criteriaQuery).getResultList();
       
        return list;
	}
	public List<PickedEntity> getPicked(){
		Session session = sessionFactory.getCurrentSession();
		List<PickedEntity> admin=new ArrayList<PickedEntity>();
		CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<PickedEntity> criteriaQuery = builder.createQuery(PickedEntity.class);
        Root<PickedEntity> root = criteriaQuery.from(PickedEntity.class);
        criteriaQuery.select(root);
        List<PickedEntity> list=session.createQuery(criteriaQuery).list();
        for(PickedEntity adm:list){
        	admin.add(adm);
	}
        return admin;
	}
	public List<FullfilledEntity> getFulfilled(){
		Session session = sessionFactory.getCurrentSession();
		List<FullfilledEntity> admin=new ArrayList<FullfilledEntity>();
		CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<FullfilledEntity> criteriaQuery = builder.createQuery(FullfilledEntity.class);
        Root<FullfilledEntity> root = criteriaQuery.from(FullfilledEntity.class);
        criteriaQuery.select(root);
        List<FullfilledEntity> list=session.createQuery(criteriaQuery).list();
        for(FullfilledEntity adm:list){
        	admin.add(adm);
	}
        return admin;
	}
}
