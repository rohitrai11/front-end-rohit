package com.infy.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.WishlistDAO;
import com.infy.entity.AdminEntity;
import com.infy.entity.EmployeeEntity;
import com.infy.entity.FullfilledEntity;
import com.infy.entity.PickedEntity;
import com.infy.entity.VolunteerEntity;
import com.infy.entity.WishesEntity;
import com.infy.model.Admin;
import com.infy.model.Employee;
import com.infy.model.Volunteer;
import com.infy.model.Wishlist;

@Service(value="service")
@Transactional(readOnly = true)
public class WishlistServiceImpl implements WishlistService{
	@Autowired
	private WishlistDAO dao;
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public PickedEntity pickWishes(Wishlist wishes) throws Exception{
		//System.out.println(wishes.getWishes()+"service");
		PickedEntity p=dao.pickWishes(wishes);
		if(p!=null && p.getStatus()=="Pending")
			return p;
		else
			throw new Exception("Service.QUANTITY_UNAVAILABLE");
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public String addWishes(Wishlist newWish) throws Exception{
		//System.out.println("service class");
		String s=dao.addWishes(newWish);
		return s;
	}
	
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void updateStatus(Integer wishId) throws Exception{
		dao.updateStatus(wishId);
	}
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Employee volunteerChoice(Employee emp)throws Exception{
		dao.volunteerChoice(emp);
		throw new Exception("Service.REQUEST_DECLINED");
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public boolean assignVolunteer(Integer vid)throws Exception{
		if(dao.assignVolunteer(vid))
			return true;
		else
			throw new Exception("Service.ASSIGNED_FAILED");
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public boolean unpickWish(Integer wishId) throws Exception{
		if(dao.unpickWish(wishId)){
			return true;
		}
		else
			throw new Exception("Service.UNPICKED_FAILED");
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public AdminEntity newAdmin(Admin admin) throws Exception{
			AdminEntity adm=dao.newAdmin(admin);
			//System.out.println(adm);
			if(adm==null){
				throw new Exception("SERVICE.ALREADY_REGISTERED");
			}
			else
				return adm;
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public EmployeeEntity newEmployee(Employee employee) throws Exception{
		EmployeeEntity adm=dao.newEmployee(employee);
			if(adm==null){
				throw new Exception("SERVICE.ALREADY_REGISTERED");
			}
			else
				return adm;
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public VolunteerEntity newVolunteer(Volunteer volunteer) throws Exception{
		VolunteerEntity adm=dao.newVolunteer(volunteer);
			if(adm==null){
				throw new Exception("SERVICE.ALREADY_REGISTERED");
			}
			else
				return adm;
	}
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public AdminEntity adminLogin(String mail,String password)throws Exception{
		AdminEntity adm=dao.adminLogin(mail,password);
		if(adm==null)
			throw new Exception("SERVICE.INVALID_LOGIN");
		else
			return adm;
	}
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public EmployeeEntity empLogin(String mail,String password)throws Exception{
		EmployeeEntity ee=dao.empLogin(mail,password);
		if(ee==null)
			throw new Exception("SERVICE.INVALID_LOGIN");
		else
			return ee;
	}
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public VolunteerEntity volLogin(String mail,String password)throws Exception{
		VolunteerEntity ve=dao.volLogin(mail,password);
		if(ve==null)
			throw new Exception("SERVICE.INVALID_LOGIN");
		else
			return ve;
	}
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void changePassword(Admin admin)throws Exception{
		//System.out.println(admin.getAdminId());
		if(!dao.changePassword(admin))
			throw new Exception("SERVICE.INVALID_ID");
	}
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void empPassword(Employee employee)throws Exception{
		//System.out.println(admin.getAdminId());
		if(!dao.empPassword(employee))
			throw new Exception("SERVICE.INVALID_ID");
	}
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public void volPassword(Volunteer volunteer)throws Exception{
		//System.out.println(admin.getAdminId());
		if(!dao.volPassword(volunteer))
			throw new Exception("SERVICE.INVALID_ID");
	}
//	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
//	public List<AdminEntity> getAdminDetails()throws Exception{
//		List<AdminEntity> list=new ArrayList<AdminEntity>();
//				list.addAll(dao.getAdminDetails());
//		return list;
//	}
//	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
//	public List<EmployeeEntity> getEmpDetails()throws Exception{
//		List<EmployeeEntity> list=new ArrayList<EmployeeEntity>();
//				list.addAll(dao.getEmpDetails());
//		return list;
//	}
//	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
//	public List<VolunteerEntity> getVolDetails()throws Exception{
//		List<VolunteerEntity> list=new ArrayList<VolunteerEntity>();
//				list.addAll(dao.getVolDetails());
//		return list;
//	}
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public List<WishesEntity> getWishlist()throws Exception{
		List<WishesEntity> list=new ArrayList<WishesEntity>();
				list.addAll(dao.getWishlist());
		return list;
	}
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public List<PickedEntity> getPicked()throws Exception{
		List<PickedEntity> list=new ArrayList<PickedEntity>();
				list.addAll(dao.getPicked());
		return list;
	}
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public List<FullfilledEntity> getFulfilled()throws Exception{
		List<FullfilledEntity> list=new ArrayList<FullfilledEntity>();
				list.addAll(dao.getFulfilled());
		return list;
	}
}
